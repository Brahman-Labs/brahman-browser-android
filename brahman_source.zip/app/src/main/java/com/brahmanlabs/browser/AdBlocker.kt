package com.brahmanlabs.browser

import android.content.Context
import android.net.Uri
import java.util.concurrent.atomic.AtomicInteger

class AdBlocker private constructor(private val context: Context) {

    private val prefs = context.getSharedPreferences("brahman_shields", Context.MODE_PRIVATE)
    private val blockedCount = AtomicInteger(0)

    companion object {
        @Volatile
        private var INSTANCE: AdBlocker? = null

        fun getInstance(context: Context): AdBlocker {
            return INSTANCE ?: synchronized(this) {
                AdBlocker(context.applicationContext).also { INSTANCE = it }
            }
        }

        private val BLOCKED_DOMAINS = setOf(
            "doubleclick.net","googleadservices.com","googlesyndication.com",
            "googletagmanager.com","googletagservices.com","google-analytics.com",
            "adservice.google.com","pagead2.googlesyndication.com",
            "connect.facebook.net","graph.facebook.com","pixel.facebook.com",
            "ads.twitter.com","static.ads-twitter.com","analytics.twitter.com",
            "amazon-adsystem.com","advertising.amazon.com",
            "outbrain.com","taboola.com","trc.taboola.com","cdn.taboola.com",
            "criteo.com","criteo.net","bidswitch.net","pubmatic.com",
            "openx.net","openx.com","rubiconproject.com","rubiconproject.net",
            "adnxs.com","ib.adnxs.com","appnexus.com","adsrvr.org",
            "turn.com","quantserve.com","quantcount.com",
            "scorecardresearch.com","comscore.com","moatads.com","moat.com",
            "chartbeat.com","chartbeat.net","static.chartbeat.com",
            "hotjar.com","static.hotjar.com","fullstory.com","rs.fullstory.com",
            "mixpanel.com","cdn.mxpnl.com","amplitude.com","api.amplitude.com",
            "segment.com","segment.io","cdn.segment.com",
            "optimizely.com","cdn.optimizely.com",
            "mouseflow.com","crazyegg.com","atdmt.com","msads.net","bat.bing.com",
            "ads.yahoo.com","adtech.de","yieldmanager.com","advertising.com",
            "adroll.com","propellerads.com","bluekai.com","bkrtx.com",
            "buysellads.com","carbonads.com","casalemedia.com",
            "contextweb.com","pulsepoint.com","demdex.net","dpm.demdex.net",
            "doubleverify.com","flashtalking.com","fwmrm.net","lkqd.net",
            "histats.com","indexww.com","lijit.com","sovrn.com","liveintent.com",
            "lotame.com","crwdcntrl.net","mathtag.com","media.net","cn.media.net",
            "mediaplex.com","mediamath.com","mopub.com","newrelic.com",
            "bam.nr-data.net","nielsen.com","imrworldwide.com","omniture.com",
            "omtrdc.net","parsely.com","permutive.com","revcontent.com",
            "rfihub.com","rlcdn.com","pippio.com","smaato.net","smartadserver.com",
            "smartclip.net","sonobi.com","spotxchange.com","spotx.tv",
            "statcounter.com","tapad.com","tradedoubler.com","triplelift.com",
            "tlx.3lift.com","undertone.com","viglink.com","webtrends.com",
            "xaxis.com","yieldmo.com","zedo.com","zeotap.com","zemanta.com",
            "pingdom.com","dataxu.com","an.yandex.ru","mc.yandex.ru",
            "adform.net","eyeota.net","tns-counter.ru","openstat.net",
            // Anti-tracking extras
            "tracking.g.doubleclick.net","stats.g.doubleclick.net",
            "adclick.g.doubleclick.net","pagead.googlesyndication.com",
            "tpc.googlesyndication.com","partnerad.l.doubleclick.net",
            "ad.doubleclick.net","mediavisor.doubleclick.net",
            "clkmon.com","clkrev.com","clkads.com",
            "traffiq.com","adzerk.net","adzerk.com",
            "bidder.criteo.com","dis.us.criteo.com","sslwidget.criteo.com",
            "tracker.marinsoftware.com","insight.adsrvr.org",
            "match.adsrvr.org","us-u.openx.net","delivery.van.eu.net",
            "fls.doubleclick.net","ad.mo.doubleclick.net",
            "pixel.quantserve.com","edge.quantserve.com",
            "secure.leadforensics.com","leadforensics.com",
            "cdn.bizible.com","bizible.com",
            "tr.snapchat.com","sc-static.net",
            "ads.linkedin.com","analytics.pointdrive.linkedin.com",
            "px.ads.linkedin.com","snap.licdn.com",
            "tiktok.com","ads.tiktok.com","analytics.tiktok.com",
            "business-api.tiktok.com",
            "intercomcdn.com","api.intercom.io","js.intercomcdn.com",
            "d3mxazbznf5or8.cloudfront.net",
            "cdn.heapanalytics.com","heapanalytics.com",
            "cdn.pendo.io","pendo.io","data.pendo.io",
            "js.driftt.com","drift.com","js.drift.com",
            "js.hs-analytics.net","js.hs-scripts.com","hubspot.com",
            "js.hsforms.net","forms.hsforms.com","api.hubspot.com",
            "js.hsleadflows.net","js.hscollectedforms.net"
        )

        // Cross-site tracking parameters to strip from URLs
        private val TRACKING_PARAMS = setOf(
            "utm_source","utm_medium","utm_campaign","utm_term","utm_content",
            "utm_id","utm_reader","utm_name","utm_social","utm_social-type",
            "fbclid","gclid","gclsrc","dclid","gbraid","wbraid",
            "msclkid","mc_eid","mkt_tok",
            "igshid","s_cid","ncid","ref","src","source",
            "_ga","_gl","yclid","obOrigUrl","twclid",
            "rb_clickid","ScCid","wickedid"
        )
    }

    // ── URL Cleaning (strip tracking params) ───────────────
    fun cleanUrl(url: String): String {
        return try {
            val uri = Uri.parse(url)
            val params = uri.queryParameterNames
            val hasTracking = params.any { TRACKING_PARAMS.contains(it.lowercase()) }
            if (!hasTracking) return url
            val builder = uri.buildUpon().clearQuery()
            params.forEach { param ->
                if (!TRACKING_PARAMS.contains(param.lowercase())) {
                    builder.appendQueryParameter(param, uri.getQueryParameter(param))
                }
            }
            builder.build().toString()
        } catch (e: Exception) { url }
    }

    // ── Shields on/off ──────────────────────────────────────
    fun isShieldsEnabled(pageUrl: String): Boolean {
        val d = domain(pageUrl); if (d.isEmpty()) return false
        return prefs.getBoolean("shield_$d", true)
    }
    fun setShieldsEnabled(pageUrl: String, v: Boolean) = set("shield_${domain(pageUrl)}", v)

    // ── HTTPS Upgrade ───────────────────────────────────────
    fun isHttpsUpgradeEnabled(pageUrl: String): Boolean {
        val d = domain(pageUrl); if (d.isEmpty()) return false
        return prefs.getBoolean("https_$d", true)
    }
    fun setHttpsUpgradeEnabled(pageUrl: String, v: Boolean) = set("https_${domain(pageUrl)}", v)

    // ── Block Scripts ───────────────────────────────────────
    fun isScriptsBlocked(pageUrl: String): Boolean {
        val d = domain(pageUrl); if (d.isEmpty()) return false
        return prefs.getBoolean("scripts_$d", false)
    }
    fun setScriptsBlocked(pageUrl: String, v: Boolean) = set("scripts_${domain(pageUrl)}", v)

    // ── Forget on close ─────────────────────────────────────
    fun isForgetOnClose(pageUrl: String): Boolean {
        val d = domain(pageUrl); if (d.isEmpty()) return false
        return prefs.getBoolean("forget_$d", false)
    }
    fun setForgetOnClose(pageUrl: String, v: Boolean) = set("forget_${domain(pageUrl)}", v)
    fun hasAnyForgetOnClose(): Boolean =
        prefs.all.entries.any { it.key.startsWith("forget_") && it.value == true }

    // ── Block Cookies ───────────────────────────────────────
    fun isCookiesBlocked(pageUrl: String): Boolean {
        val d = domain(pageUrl); if (d.isEmpty()) return false
        return prefs.getBoolean("cookies_$d", false)
    }
    fun setCookiesBlocked(pageUrl: String, v: Boolean) = set("cookies_${domain(pageUrl)}", v)

    // ── Block Fingerprinting ────────────────────────────────
    fun isFingerprintingBlocked(pageUrl: String): Boolean {
        val d = domain(pageUrl); if (d.isEmpty()) return false
        return prefs.getBoolean("fp_$d", true)
    }
    fun setFingerprintingBlocked(pageUrl: String, v: Boolean) = set("fp_${domain(pageUrl)}", v)

    // ── Ad blocking ─────────────────────────────────────────
    fun shouldBlock(requestUrl: String): Boolean {
        return try {
            val h = Uri.parse(requestUrl).host?.lowercase() ?: return false
            BLOCKED_DOMAINS.any { d -> h == d || h.endsWith(".$d") }
        } catch (e: Exception) { false }
    }

    fun incrementBlockedCount() { blockedCount.incrementAndGet() }
    fun getBlockedCount(): Int = blockedCount.get()
    fun resetBlockedCount() { blockedCount.set(0) }

    private fun set(key: String, v: Boolean) = prefs.edit().putBoolean(key, v).apply()
    fun domain(url: String): String = try {
        Uri.parse(url).host?.removePrefix("www.") ?: ""
    } catch (e: Exception) { "" }
}
