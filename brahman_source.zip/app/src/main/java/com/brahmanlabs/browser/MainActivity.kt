package com.brahmanlabs.browser

import android.Manifest
import android.app.Activity
import android.app.DownloadManager
import android.app.PictureInPictureParams
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.print.PrintManager
import android.speech.RecognizerIntent
import android.text.Editable
import android.text.TextWatcher
import android.util.Rational
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updateLayoutParams
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var webViewContainer: FrameLayout
    private lateinit var lockIcon: ImageView
    private lateinit var addressBar: EditText
    private lateinit var progressBar: ProgressBar
    private lateinit var addressBarRow: LinearLayout
    private lateinit var navigationBar: LinearLayout
    private lateinit var topBar: LinearLayout
    private lateinit var tabsRow: LinearLayout
    private lateinit var btnBookmark: ImageButton
    private lateinit var btnIncognito: ImageButton
    private lateinit var btnDesktop: ImageButton
    private lateinit var btnShield: ImageButton
    private lateinit var shieldBadge: TextView
    private lateinit var btnMore: ImageButton
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnRefresh: ImageButton
    private lateinit var btnHome: ImageButton
    private lateinit var btnNewTab: ImageButton
    private lateinit var btnTabGrid: ImageButton
    private lateinit var btnFullscreen: ImageButton
    private lateinit var btnMic: ImageButton
    private lateinit var tabRecycler: RecyclerView
    private lateinit var findInPageBar: LinearLayout
    private lateinit var findInput: EditText
    private lateinit var findMatchCount: TextView
    private lateinit var btnFindPrev: ImageButton
    private lateinit var btnFindNext: ImageButton
    private lateinit var btnFindClose: ImageButton
    private lateinit var tabGridOverlay: RelativeLayout
    private lateinit var tabGridRecycler: RecyclerView
    private lateinit var tabCountLabel: TextView
    private lateinit var btnGridClose: ImageButton
    private lateinit var btnGridNewTab: ImageButton
    private lateinit var btnCloseAllTabs: Button
    private lateinit var btnGridAddNewTab: Button
    private lateinit var fullscreenVideoContainer: FrameLayout
    private lateinit var suggestionsPanel: LinearLayout
    private lateinit var suggestionsRecycler: RecyclerView
    private lateinit var suggestionAdapter: SuggestionAdapter

    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var originalOrientation = 0
    private var originalSystemUiVisibility = 0
    private var isAddressBarFocused = false
    private var isReaderModeOn = false
    private var isFullscreen = false

    private val tabManager = TabManager()
    private lateinit var browserAdapter: BrowserAdapter
    private lateinit var db: BrahmanDatabase
    private lateinit var prefs: BrahmanPreferences
    private lateinit var adBlocker: AdBlocker
    private lateinit var gestureDetector: GestureDetector

    private val closedTabHistory = mutableListOf<String>()
    private val NEW_TAB_URL = "file:///android_asset/newtab.html"
    private val historyDebounceHandler = Handler(Looper.getMainLooper())
    private var historyDebounceRunnable: Runnable? = null
    private val suggestionHandler = Handler(Looper.getMainLooper())
    private var suggestionRunnable: Runnable? = null

    companion object {
        private const val PERMISSION_REQUEST_CODE = 100

        private const val FP_JS = """
(function(){
  try{
    var orig=HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext=function(t,a){
      var ctx=orig.call(this,t,a);
      if(ctx&&t==='2d'){
        var oi=ctx.getImageData.bind(ctx);
        ctx.getImageData=function(x,y,w,h){
          var d=oi(x,y,w,h);
          for(var i=0;i<d.data.length;i+=4){d.data[i]^=1;}
          return d;
        };
      }
      return ctx;
    };
    try{Object.defineProperty(navigator,'hardwareConcurrency',{get:function(){return 4;},configurable:true});}catch(e){}
    try{Object.defineProperty(screen,'colorDepth',{get:function(){return 24;},configurable:true});}catch(e){}
    try{Object.defineProperty(navigator,'plugins',{get:function(){return[];},configurable:true});}catch(e){}
    try{Object.defineProperty(navigator,'languages',{get:function(){return['en-US'];},configurable:true});}catch(e){}
  }catch(e){}
})();
"""
        private const val NIGHT_MODE_JS = """
(function(){
  var s=document.getElementById('__brahman_night__');
  if(!s){s=document.createElement('style');s.id='__brahman_night__';document.head.appendChild(s);}
  s.textContent='html{filter:invert(1) hue-rotate(180deg)!important;}img,video,canvas,iframe{filter:invert(1) hue-rotate(180deg)!important;}';
})();
"""
        private const val READER_JS = """
(function(){
  try{
    var c=document.querySelector('article')||document.querySelector('[role="main"]')||
      document.querySelector('main')||document.querySelector('.post-content')||
      document.querySelector('.entry-content')||document.body;
    var title=document.title||'';
    var clone=c.cloneNode(true);
    clone.querySelectorAll('script,style,nav,header,footer,aside,iframe,.ad,.ads,'+
      '[class*="ad-"],[id*="ad-"],[class*="banner"],[class*="sidebar"],'+
      '[class*="popup"],[class*="cookie"],[class*="newsletter"]')
      .forEach(function(el){el.remove();});
    document.body.innerHTML='<div id="br-reader"><h1 id="br-t"></h1><div id="br-c"></div></div>';
    document.getElementById('br-t').textContent=title;
    document.getElementById('br-c').innerHTML=clone.innerHTML;
    var s=document.createElement('style');
    s.textContent='*{max-width:100%!important;}body{background:#050E1F!important;color:#CAF0F8!important;'+
      'font-family:Georgia,serif!important;padding:20px 16px!important;max-width:680px!important;'+
      'margin:0 auto!important;font-size:17px!important;line-height:1.85!important;}'+
      'h1{color:#00B4D8!important;font-size:21px!important;margin-bottom:20px!important;}'+
      'img{max-width:100%!important;height:auto!important;border-radius:8px!important;}'+
      'a{color:#48CAE4!important;}p{margin-bottom:14px!important;}'+
      'h2,h3,h4{color:#90E0EF!important;margin:16px 0 8px!important;}';
    document.head.appendChild(s);
  }catch(e){}
})();
"""
        private const val PW_DETECT_JS = """
(function(){
  if(window.__brahman_pw__)return;
  window.__brahman_pw__=true;
  document.querySelectorAll('form').forEach(function(form){
    var pw=form.querySelector('input[type="password"]');
    var user=form.querySelector('input[type="text"],input[type="email"],input[name*="user"],input[name*="email"],input[id*="user"],input[id*="email"]');
    if(pw){form.addEventListener('submit',function(){
      var u=user?user.value:'',p=pw.value;
      if(u&&p)try{window.BrahmanBridge.onPasswordDetected(u,p);}catch(e){}
    },true);}
  });
})();
"""
    }

    // ── Launchers ─────────────────────────────────────────────

    private val historyLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK)
            result.data?.getStringExtra("url")?.let { loadUrl(it) }
    }

    private val bookmarkLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK)
            result.data?.getStringExtra("url")?.let { loadUrl(it) }
    }

    private val settingsLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            progressBar.visibility = View.GONE
            swipeRefresh.isRefreshing = false
            applySettingsToCurrentWebView()
        }
    }

    private val downloadLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { }

    private val passwordLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { }

    private val readingLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK)
            result.data?.getStringExtra("url")?.let { loadUrl(it) }
    }

    private val voiceLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val q = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!q.isNullOrEmpty()) loadUrl(prefs.getSearchUrl(q))
        }
    }

    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val results = if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { arrayOf(it) }
                ?: result.data?.clipData?.let { clip ->
                    Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                }
        } else null
        fileUploadCallback?.onReceiveValue(results)
        fileUploadCallback = null
    }

    private val qrScanLauncher = registerForActivityResult(ScanContract()) { result ->
        result.contents?.let { content ->
            loadUrl(
                if (content.startsWith("http://") || content.startsWith("https://")) content
                else prefs.getSearchUrl(content)
            )
            Toast.makeText(this, "QR: $content", Toast.LENGTH_SHORT).show()
        }
    }

    // ── Lifecycle ─────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        db = BrahmanDatabase.getInstance(this)
        prefs = BrahmanPreferences.getInstance(this)
        adBlocker = AdBlocker.getInstance(this)
        bindViews()
        setupWindowInsets()
        setupGestureDetector()
        setupSuggestions()
        setupRecyclerView()
        setupSwipeRefresh()
        setupListeners()
        setupTabGrid()
        CookieManager.getInstance().setAcceptCookie(true)

        if (!handleShortcutIntent(intent)) {
            val urlFromIntent = resolveIncomingIntent(intent)
            if (urlFromIntent != null) {
                openTab(urlFromIntent)
            } else {
                val (savedTabs, savedIndex) = SessionManager.loadSession(this)
                if (savedTabs.isNotEmpty()) {
                    showRestoreSessionDialog(savedTabs, savedIndex)
                } else {
                    openTab(NEW_TAB_URL)
                }
            }
        } else {
            openTab(NEW_TAB_URL)
        }
    }

    // ── Multi-WebView Architecture ────────────────────────────

    private fun createWebView(): WebView {
        val wv = WebView(this)
        wv.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        wv.visibility = View.GONE
        applyWebViewSettings(wv)
        applyWebViewClients(wv)
        webViewContainer.addView(wv)
        return wv
    }

    private fun openTab(url: String, incognito: Boolean = false) {
        getCurrentWebView()?.visibility = View.GONE
        val wv = createWebView()
        val tab = BrowserTab(url = url, isIncognito = incognito, webView = wv)
        tabManager.addTab(tab)
        browserAdapter.notifyDataSetChanged()
        tabRecycler.scrollToPosition(tabManager.tabs.lastIndex)
        wv.visibility = View.VISIBLE
        wv.loadUrl(url)
        updateUIForUrl(url)
        updateNavButtons()
        updateShieldIcon(url)
        updateSwipeRefreshTarget()
    }

    private fun switchToExistingTab(index: Int) {
        if (index !in tabManager.tabs.indices) return
        val oldIndex = tabManager.getCurrentTabIndex()
        getCurrentWebView()?.visibility = View.GONE
        tabManager.switchToTab(index)
        val tab = tabManager.getCurrentTab() ?: return
        if (tab.webView == null) {
            val wv = createWebView()
            tab.webView = wv
            wv.loadUrl(tab.url)
        }
        tab.webView?.visibility = View.VISIBLE
        updateUIForUrl(tab.url)
        updateNavButtons()
        updateShieldIcon(tab.url)
        updateSwipeRefreshTarget()
        browserAdapter.notifyItemChanged(oldIndex)
        browserAdapter.notifyItemChanged(index)
        tabRecycler.scrollToPosition(index)
    }

    private fun closeTab(index: Int) {
        val tab = tabManager.tabs.getOrNull(index) ?: return
        if (!tab.url.startsWith("file://")) closedTabHistory.add(tab.url)
        if (adBlocker.isForgetOnClose(tab.url)) {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
        }
        tab.webView?.let { wv -> webViewContainer.removeView(wv); wv.destroy() }
        tab.webView = null
        tabManager.removeTab(index)
        browserAdapter.notifyDataSetChanged()
        if (tabManager.tabs.isEmpty()) {
            openTab(NEW_TAB_URL)
        } else {
            val currentTab = tabManager.getCurrentTab()
            currentTab?.webView?.visibility = View.VISIBLE
            val url = currentTab?.url ?: NEW_TAB_URL
            updateUIForUrl(url)
            updateNavButtons()
            updateShieldIcon(url)
            updateSwipeRefreshTarget()
        }
    }

    private fun getCurrentWebView(): WebView? = tabManager.getCurrentTab()?.webView

    private fun updateSwipeRefreshTarget() {
        swipeRefresh.setOnChildScrollUpCallback { _, _ ->
            getCurrentWebView()?.canScrollVertically(-1) ?: false
        }
    }

    // ── WebView Settings ──────────────────────────────────────

    private fun applyWebViewSettings(wv: WebView) {
        wv.settings.apply {
            javaScriptEnabled = prefs.javascriptEnabled
            domStorageEnabled = true
            databaseEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            allowFileAccess = true
            allowContentAccess = true
            textZoom = prefs.textSize
            mediaPlaybackRequiresUserGesture = prefs.blockAutoplay
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            setGeolocationEnabled(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            blockNetworkImage = prefs.dataSaverEnabled
            loadsImagesAutomatically = !prefs.dataSaverEnabled
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)

        wv.addJavascriptInterface(object {
            @android.webkit.JavascriptInterface
            fun loadUrl(url: String) { runOnUiThread { this@MainActivity.loadUrl(url) } }
            @android.webkit.JavascriptInterface
            fun getSearchEngine(): String = prefs.searchEngine
            @android.webkit.JavascriptInterface
            fun getWallpaper(): String = prefs.newTabWallpaper
            @android.webkit.JavascriptInterface
            fun setWallpaper(wp: String) { prefs.newTabWallpaper = wp }
            @android.webkit.JavascriptInterface
            fun onPasswordDetected(username: String, password: String) {
                val tab = tabManager.getCurrentTab() ?: return
                if (tab.isIncognito) return
                val domain = extractDomain(tab.url)
                if (domain.isEmpty()) return
                runOnUiThread {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("💾 Save Password?")
                        .setMessage("Save login for $domain?\n\nUsername: $username")
                        .setPositiveButton("Save") { _, _ ->
                            lifecycleScope.launch {
                                db.passwordDao().insert(
                                    PasswordItem(
                                        domain = domain,
                                        username = PasswordEncryption.encrypt(username),
                                        password = PasswordEncryption.encrypt(password)
                                    )
                                )
                                runOnUiThread {
                                    Toast.makeText(this@MainActivity,
                                        "🔑 Password saved for $domain",
                                        Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                        .setNegativeButton("Not now", null).show()
                }
            }
        }, "BrahmanBridge")

        wv.setOnTouchListener { _, event -> gestureDetector.onTouchEvent(event); false }

        wv.setOnLongClickListener {
            val result = wv.hitTestResult
            val extra = result.extra ?: return@setOnLongClickListener false
            when (result.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE,
                WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> { showLinkOptions(extra); true }
                WebView.HitTestResult.IMAGE_TYPE -> { showImageOptions(extra); true }
                else -> false
            }
        }

        wv.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimetype)
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(
                DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mimetype)
                    .addRequestHeader("User-Agent", userAgent)
                    .setDescription("Downloading...").setTitle(fileName)
                    .setNotificationVisibility(
                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(
                        Environment.DIRECTORY_DOWNLOADS, fileName))
            lifecycleScope.launch {
                db.downloadDao().insert(
                    DownloadItem(fileName = fileName, url = url, mimeType = mimetype))
            }
            Toast.makeText(this, "Downloading: $fileName", Toast.LENGTH_SHORT).show()
        }

        wv.setFindListener { activeMatchOrdinal, numberOfMatches, _ ->
            if (wv == getCurrentWebView()) {
                findMatchCount.text = if (numberOfMatches == 0) "No matches"
                else "${activeMatchOrdinal + 1} / $numberOfMatches"
            }
        }
    }

    private fun applyWebViewClients(wv: WebView) {
        wv.webViewClient = object : WebViewClient() {

            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                val tab = tabManager.tabs.find { it.webView == view } ?: return null
                val reqUrl = request.url.toString()
                if (adBlocker.isShieldsEnabled(tab.url) && adBlocker.shouldBlock(reqUrl)) {
                    adBlocker.incrementBlockedCount()
                    if (tab == tabManager.getCurrentTab())
                        runOnUiThread { updateShieldBadge() }
                    return WebResourceResponse("text/plain", "utf-8", null)
                }
                return null
            }

            override fun shouldOverrideUrlLoading(
                view: WebView, request: WebResourceRequest
            ): Boolean {
                val url = request.url.toString()
                if (url.startsWith("file://")) return false
                if (url.startsWith("javascript:") || url.startsWith("data:")) return false
                if (url.startsWith("view-source:")) { view.loadUrl(url); return false }
                val tab = tabManager.tabs.find { it.webView == view }
                val pageUrl = tab?.url ?: ""
                val cleanedUrl = if (adBlocker.isShieldsEnabled(pageUrl))
                    adBlocker.cleanUrl(url) else url
                if (cleanedUrl.startsWith("http://") &&
                    adBlocker.isShieldsEnabled(pageUrl) &&
                    adBlocker.isHttpsUpgradeEnabled(pageUrl) &&
                    !pageUrl.startsWith("https://")) {
                    view.loadUrl(cleanedUrl.replaceFirst("http://", "https://"))
                    return true
                }
                view.loadUrl(cleanedUrl)
                return true
            }

            override fun onReceivedError(
                view: WebView, request: WebResourceRequest, error: WebResourceError
            ) {
                if (request.isForMainFrame) {
                    try {
                        val encodedUrl = URLEncoder.encode(request.url.toString(), "UTF-8")
                        val encodedErr = URLEncoder.encode(
                            "Error ${error.errorCode}: ${error.description}", "UTF-8")
                        view.loadUrl(
                            "file:///android_asset/error_page.html" +
                                "?url=$encodedUrl&error=$encodedErr")
                    } catch (e: Exception) { }
                }
            }

            override fun onReceivedSslError(
                view: WebView, handler: SslErrorHandler,
                error: android.net.http.SslError
            ) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("⚠️ Security Warning")
                    .setMessage("This site has an SSL certificate issue. Proceed anyway?")
                    .setPositiveButton("Proceed") { _, _ -> handler.proceed() }
                    .setNegativeButton("Go Back") { _, _ -> handler.cancel() }.show()
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                val tab = tabManager.tabs.find { it.webView == view } ?: return
                tab.url = url
                if (tab == tabManager.getCurrentTab()) {
                    runOnUiThread {
                        adBlocker.resetBlockedCount()
                        isReaderModeOn = false
                        updateShieldBadge()
                        val isNewTab = url.startsWith("file://")
                        view.settings.setSupportZoom(!isNewTab)
                        view.settings.builtInZoomControls = !isNewTab
                        closeFindInPage()
                        hideSuggestions()
                        progressBar.visibility = View.VISIBLE
                        progressBar.progress = 0
                    }
                }
                if (!url.startsWith("file://")) {
                    view.settings.javaScriptEnabled =
                        if (adBlocker.isScriptsBlocked(url)) false
                        else prefs.javascriptEnabled
                    val cookiesBlocked = adBlocker.isCookiesBlocked(url)
                    CookieManager.getInstance().setAcceptCookie(!cookiesBlocked)
                    CookieManager.getInstance()
                        .setAcceptThirdPartyCookies(view, !cookiesBlocked)
                }
            }

            override fun onPageFinished(view: WebView, url: String) {
                val tab = tabManager.tabs.find { it.webView == view } ?: return
                val isCurrentTab = tab == tabManager.getCurrentTab()
                val isNewTab = url.startsWith("file://")
                val isErrorPage = url.contains("error_page.html")
                val isHttps = url.startsWith("https://")

                tab.url = url
                tab.title = if (isNewTab) "New Tab" else (view.title ?: "New Tab")
                if (isNewTab) tab.favicon = null
                val tabIndex = tabManager.tabs.indexOf(tab)
                runOnUiThread { browserAdapter.notifyItemChanged(tabIndex) }

                if (isCurrentTab) {
                    runOnUiThread {
                        swipeRefresh.isRefreshing = false
                        progressBar.visibility = View.GONE
                        hideSuggestions()
                        isAddressBarFocused = false
                        addressBarRow.visibility = if (isNewTab) View.GONE else View.VISIBLE
                        lockIcon.visibility = if (isHttps) View.VISIBLE else View.GONE
                        updateNavButtons()
                        updateShieldIcon(url)
                        if (isNewTab) {
                            setAddressBarSilently("")
                            addressBar.hint = "Search or type URL"
                            btnBookmark.setImageResource(R.drawable.ic_bookmark)
                            btnBookmark.alpha = 0.4f
                            loadFrequentSites(view)
                        } else {
                            setAddressBarSilently(extractDomain(url))
                            updateBookmarkIcon(url)
                            if (adBlocker.isShieldsEnabled(url) &&
                                adBlocker.isFingerprintingBlocked(url))
                                view.evaluateJavascript(FP_JS, null)
                            if (!url.contains("translate.google.com") &&
                                prefs.nightModeEnabled)
                                view.evaluateJavascript(NIGHT_MODE_JS, null)
                            if (!isErrorPage && !tab.isIncognito) {
                                view.evaluateJavascript(PW_DETECT_JS, null)
                                injectSavedPassword(view, url)
                            }
                        }
                    }
                }

                if (!isNewTab && !isErrorPage && !tab.isIncognito) {
                    historyDebounceRunnable?.let {
                        historyDebounceHandler.removeCallbacks(it)
                    }
                    historyDebounceRunnable = Runnable {
                        val currentUrl = view.url ?: url
                        lifecycleScope.launch {
                            db.historyDao().insert(
                                HistoryItem(
                                    title = view.title ?: "Page",
                                    url = currentUrl
                                )
                            )
                        }
                    }
                    historyDebounceHandler.postDelayed(historyDebounceRunnable!!, 800)
                }
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (view == getCurrentWebView()) {
                    progressBar.progress = newProgress
                    progressBar.visibility =
                        if (newProgress < 100) View.VISIBLE else View.GONE
                }
            }

            override fun onReceivedTitle(view: WebView, title: String) {
                val tab = tabManager.tabs.find { it.webView == view } ?: return
                tab.title = title
                runOnUiThread {
                    browserAdapter.notifyItemChanged(tabManager.tabs.indexOf(tab))
                }
            }

            override fun onReceivedIcon(view: WebView, icon: Bitmap) {
                val tab = tabManager.tabs.find { it.webView == view } ?: return
                tab.favicon = icon
                runOnUiThread {
                    browserAdapter.notifyItemChanged(tabManager.tabs.indexOf(tab))
                }
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                showVideoFullscreen(view, callback)
            }
            override fun onHideCustomView() { hideVideoFullscreen() }

            override fun onShowFileChooser(
                webView: WebView, filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback
                try { fileChooserLauncher.launch(fileChooserParams.createIntent()) }
                catch (e: Exception) { fileUploadCallback = null; return false }
                return true
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String, callback: GeolocationPermissions.Callback
            ) {
                AlertDialog.Builder(this@MainActivity).setTitle("Location Access")
                    .setMessage("$origin wants your location")
                    .setPositiveButton("Allow") { _, _ ->
                        requestPermissionsIfNeeded(arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION))
                        callback.invoke(origin, true, false)
                    }
                    .setNegativeButton("Deny") { _, _ ->
                        callback.invoke(origin, false, false)
                    }.show()
            }

            override fun onPermissionRequest(request: PermissionRequest) {
                val resources = request.resources
                val needCamera = resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                val needMic = resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                if (prefs.blockNotifications && !needCamera && !needMic) {
                    request.deny(); return
                }
                val permsNeeded = mutableListOf<String>()
                if (needCamera) permsNeeded.add(Manifest.permission.CAMERA)
                if (needMic) permsNeeded.add(Manifest.permission.RECORD_AUDIO)
                if (permsNeeded.isNotEmpty()) {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Permission Request")
                        .setMessage("${request.origin} wants access")
                        .setPositiveButton("Allow") { _, _ ->
                            requestPermissionsIfNeeded(permsNeeded.toTypedArray())
                            request.grant(resources)
                        }
                        .setNegativeButton("Deny") { _, _ -> request.deny() }.show()
                } else request.grant(resources)
            }

            override fun onJsAlert(view: WebView, url: String, message: String,
                result: android.webkit.JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setTitle(extractDomain(url))
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }

            override fun onJsConfirm(view: WebView, url: String, message: String,
                result: android.webkit.JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setTitle(extractDomain(url))
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }.show()
                return true
            }

            override fun onJsPrompt(view: WebView, url: String, message: String,
                defaultValue: String?, result: android.webkit.JsPromptResult): Boolean {
                val input = EditText(this@MainActivity).apply { setText(defaultValue ?: "") }
                AlertDialog.Builder(this@MainActivity).setTitle(extractDomain(url))
                    .setMessage(message).setView(input)
                    .setPositiveButton("OK") { _, _ -> result.confirm(input.text.toString()) }
                    .setNegativeButton("Cancel") { _, _ -> result.cancel() }.show()
                return true
            }
        }
    }

    private fun applySettingsToCurrentWebView() {
        getCurrentWebView()?.settings?.apply {
            javaScriptEnabled = prefs.javascriptEnabled
            textZoom = prefs.textSize
            mediaPlaybackRequiresUserGesture = prefs.blockAutoplay
            blockNetworkImage = prefs.dataSaverEnabled
            loadsImagesAutomatically = !prefs.dataSaverEnabled
        }
    }

    // ── URL Loading ───────────────────────────────────────────

    fun loadUrl(url: String) {
        isAddressBarFocused = false
        hideSuggestions()
        val tab = tabManager.getCurrentTab() ?: return
        tab.url = url
        getCurrentWebView()?.loadUrl(url)
        updateUIForUrl(url)
        updateNavButtons()
    }

    private fun updateUIForUrl(url: String) {
        val isNewTab = url.startsWith("file://")
        addressBarRow.visibility = if (isNewTab) View.GONE else View.VISIBLE
        if (isNewTab) {
            addressBar.clearFocus()
            addressBar.setText("")
            addressBar.hint = "Search or type URL"
            lockIcon.visibility = View.GONE
            btnBookmark.setImageResource(R.drawable.ic_bookmark)
            btnBookmark.alpha = 0.4f
        } else {
            setAddressBarSilently(extractDomain(url))
        }
    }

    private fun setAddressBarSilently(text: String) {
        isAddressBarFocused = false
        addressBar.clearFocus()
        addressBar.setText(text)
    }

    // ── SwipeRefresh ──────────────────────────────────────────

    private fun setupSwipeRefresh() {
        swipeRefresh.setOnRefreshListener { getCurrentWebView()?.reload() }
        swipeRefresh.setColorSchemeColors(
            getColor(R.color.waterCyan),
            getColor(R.color.waterCyanLight),
            getColor(R.color.waterFoam)
        )
        swipeRefresh.setProgressBackgroundColorSchemeColor(getColor(R.color.waterMid))
        updateSwipeRefreshTarget()
    }

    // ── Suggestions — Live Search + History + Bookmarks ──────

    private fun setupSuggestions() {
        suggestionAdapter = SuggestionAdapter(
            items = emptyList(),
            onItemClick = { suggestion ->
                hideSuggestions(); hideKeyboard()
                when {
                    suggestion.isSearch || suggestion.isSearchSuggest ->
                        loadUrl(prefs.getSearchUrl(suggestion.text))
                    suggestion.text.startsWith("http://") ||
                        suggestion.text.startsWith("https://") ->
                        loadUrl(suggestion.text)
                    suggestion.text.contains(".") && !suggestion.text.contains(" ") ->
                        loadUrl("https://${suggestion.text}")
                    else -> loadUrl(prefs.getSearchUrl(suggestion.text))
                }
            },
            onFillClick = { suggestion ->
                addressBar.setText(suggestion.text)
                addressBar.setSelection(suggestion.text.length)
            }
        )
        suggestionsRecycler.layoutManager = LinearLayoutManager(this)
        suggestionsRecycler.adapter = suggestionAdapter
    }

    private fun updateSuggestions(query: String) {
        if (!isAddressBarFocused || query.isEmpty()) { hideSuggestions(); return }

        lifecycleScope.launch {
            val suggestions = mutableListOf<Suggestion>()
            val isUrl = query.contains("://") ||
                (query.contains(".") && !query.contains(" ") && query.length > 4)

            // 1. Direct search option at top (only for non-URL queries)
            if (!isUrl) {
                suggestions.add(
                    Suggestion(
                        text = query,
                        displayText = "Search \"$query\"",
                        subText = when (prefs.searchEngine) {
                            BrahmanPreferences.ENGINE_DDG -> "DuckDuckGo"
                            BrahmanPreferences.ENGINE_BING -> "Bing"
                            else -> "Google"
                        },
                        isSearch = true
                    )
                )
            }

            // 2. Bookmarks
            try {
                db.bookmarkDao().search("%$query%").take(2).forEach { item ->
                    val domain = extractDomain(item.url)
                    suggestions.add(
                        Suggestion(
                            text = item.url,
                            displayText = item.title.ifEmpty { domain },
                            subText = domain,
                            isBookmark = true
                        )
                    )
                }
            } catch (e: Exception) { }

            // 3. History
            try {
                db.historyDao().search("%$query%").take(3).forEach { item ->
                    if (suggestions.none { it.text == item.url }) {
                        val domain = extractDomain(item.url)
                        suggestions.add(
                            Suggestion(
                                text = item.url,
                                displayText = item.title.ifEmpty { domain },
                                subText = domain,
                                isHistory = true
                            )
                        )
                    }
                }
            } catch (e: Exception) { }

            // 4. Live internet search suggestions
            if (!isUrl) {
                try {
                    val internetSuggestions = withContext(Dispatchers.IO) {
                        fetchSearchSuggestions(query)
                    }
                    internetSuggestions.forEach { suggest ->
                        if (suggest != query &&
                            suggestions.none { it.displayText == suggest }) {
                            suggestions.add(
                                Suggestion(
                                    text = suggest,
                                    displayText = suggest,
                                    isSearchSuggest = true
                                )
                            )
                        }
                    }
                } catch (e: Exception) { }
            }

            runOnUiThread {
                if (isAddressBarFocused && suggestions.isNotEmpty()) {
                    suggestionAdapter.updateList(suggestions.take(8))
                    suggestionsPanel.visibility = View.VISIBLE
                } else if (!isAddressBarFocused) {
                    hideSuggestions()
                }
            }
        }
    }

    private fun fetchSearchSuggestions(query: String): List<String> {
        return try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val suggestUrl = when (prefs.searchEngine) {
                BrahmanPreferences.ENGINE_DDG ->
                    "https://duckduckgo.com/ac/?q=$encoded&type=list"
                BrahmanPreferences.ENGINE_BING ->
                    "https://api.bing.com/osjson.aspx?query=$encoded"
                else ->
                    "https://suggestqueries.google.com/complete/search?client=firefox&q=$encoded"
            }
            val conn = URL(suggestUrl).openConnection() as HttpURLConnection
            conn.connectTimeout = 1500
            conn.readTimeout = 1500
            conn.setRequestProperty("User-Agent", "Mozilla/5.0")
            val response = conn.inputStream.bufferedReader().readText()
            conn.disconnect()
            // Parse [query, [suggestion1, suggestion2, ...]]
            val arr = JSONArray(response).getJSONArray(1)
            (0 until minOf(arr.length(), 5)).map { arr.getString(it) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun hideSuggestions() {
        suggestionsPanel.visibility = View.GONE
        suggestionRunnable?.let { suggestionHandler.removeCallbacks(it) }
    }

    // ── Password Autofill ─────────────────────────────────────

    private fun injectSavedPassword(view: WebView, url: String) {
        val domain = extractDomain(url)
        lifecycleScope.launch {
            val saved = db.passwordDao().getByDomain(domain) ?: return@launch
            val u = PasswordEncryption.decrypt(saved.username).replace("'", "\\'")
            val p = PasswordEncryption.decrypt(saved.password).replace("'", "\\'")
            val js = """
                (function(){
                  var pw=document.querySelector('input[type="password"]');
                  var user=document.querySelector('input[type="text"],input[type="email"],'+
                    'input[name*="user"],input[name*="email"],input[id*="user"],input[id*="email"]');
                  if(pw){if(user)user.value='$u';pw.value='$p';
                    var t=document.createElement('div');
                    t.textContent='🔑 Password autofilled';
                    t.style.cssText='position:fixed;bottom:80px;left:50%;transform:translateX(-50%);'+
                      'background:#0A2A4A;color:#00B4D8;padding:8px 16px;border-radius:20px;'+
                      'font-size:13px;z-index:99999;border:1px solid #00B4D8;pointer-events:none;';
                    document.body.appendChild(t);
                    setTimeout(function(){if(t.parentNode)t.parentNode.removeChild(t);},2000);}
                })();
            """.trimIndent()
            runOnUiThread { view.evaluateJavascript(js, null) }
        }
    }

    // ── Frequent Sites ────────────────────────────────────────

    private fun loadFrequentSites(view: WebView) {
        lifecycleScope.launch {
            val items = db.historyDao().getAll()
            val domainMap = mutableMapOf<String, Pair<String, Int>>()
            items.forEach { item ->
                try {
                    val domain = Uri.parse(item.url).host?.removePrefix("www.")
                        ?: return@forEach
                    if (domain.isEmpty() || domain.startsWith("file")) return@forEach
                    val existing = domainMap[domain]
                    domainMap[domain] = if (existing == null) Pair(item.url, 1)
                    else Pair(existing.first, existing.second + 1)
                } catch (e: Exception) { }
            }
            val top8 = domainMap.entries.sortedByDescending { it.value.second }.take(8)
                .map { entry ->
                    val domain = entry.key
                    val url = entry.value.first
                        .replace("\\", "\\\\").replace("\"", "\\\"")
                        .replace("'", "\\'")
                    val letter = domain.firstOrNull()?.uppercaseChar()?.toString() ?: "?"
                    """{"domain":"$domain","url":"$url","letter":"$letter"}"""
                }
            if (top8.isNotEmpty()) {
                val json = "[${top8.joinToString(",")}]".replace("'", "\\'")
                runOnUiThread {
                    view.evaluateJavascript(
                        "if(typeof brahmanSetFrequent==='function')" +
                            "brahmanSetFrequent('$json');", null)
                }
            }
        }
    }

    // ── Fullscreen / PiP ──────────────────────────────────────

    private fun showVideoFullscreen(
        view: View, callback: WebChromeClient.CustomViewCallback
    ) {
        customView = view; customViewCallback = callback
        originalOrientation = requestedOrientation
        originalSystemUiVisibility = window.decorView.systemUiVisibility
        fullscreenVideoContainer.addView(view)
        fullscreenVideoContainer.visibility = View.VISIBLE
        topBar.visibility = View.GONE
        tabsRow.visibility = View.GONE
        navigationBar.visibility = View.GONE
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        requestedOrientation =
            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    private fun hideVideoFullscreen() {
        customView?.let { fullscreenVideoContainer.removeView(it) }
        customView = null
        fullscreenVideoContainer.visibility = View.GONE
        topBar.visibility = View.VISIBLE
        tabsRow.visibility = View.VISIBLE
        navigationBar.visibility = View.VISIBLE
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        window.decorView.systemUiVisibility = originalSystemUiVisibility
        requestedOrientation = originalOrientation
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
    }

    private fun toggleFullscreen() {
        isFullscreen = !isFullscreen
        if (isFullscreen) {
            topBar.visibility = View.GONE
            tabsRow.visibility = View.GONE
            navigationBar.visibility = View.GONE
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            Toast.makeText(this, "Full screen — back to exit", Toast.LENGTH_SHORT).show()
        } else {
            topBar.visibility = View.VISIBLE
            tabsRow.visibility = View.VISIBLE
            navigationBar.visibility = View.VISIBLE
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        }
    }

    private fun enterPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder()
                        .setAspectRatio(Rational(16, 9)).build())
            } catch (e: Exception) { }
        }
    }

    // ── Features ──────────────────────────────────────────────

    private fun showCertificateInfo() {
        val wv = getCurrentWebView() ?: return
        val cert = wv.certificate
        val currentUrl = tabManager.getCurrentTab()?.url ?: ""
        if (cert == null || currentUrl.startsWith("file://")) {
            AlertDialog.Builder(this).setTitle("Connection Info")
                .setMessage("⚠️ This page is NOT secure (HTTP).")
                .setPositiveButton("OK", null).show()
            return
        }
        val fmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        AlertDialog.Builder(this).setTitle("🔒 Certificate Details")
            .setMessage(buildString {
                append("Secure Connection (HTTPS)\n\n")
                append("Issued To\n  ${cert.issuedTo.cName}\n\n")
                append("Issued By\n  ${cert.issuedBy.cName}\n\n")
                append("Valid: ${fmt.format(Date(cert.validNotBeforeDate.time))} → " +
                    "${fmt.format(Date(cert.validNotAfterDate.time))}")
            })
            .setPositiveButton("OK", null).show()
    }

    private fun translatePage() {
        val url = tabManager.getCurrentTab()?.url ?: ""
        if (url.startsWith("file://")) {
            Toast.makeText(this, "Cannot translate this page", Toast.LENGTH_SHORT).show()
            return
        }
        val languages = arrayOf("English","Hindi","Spanish","French","German",
            "Arabic","Chinese","Japanese","Korean","Portuguese",
            "Russian","Italian","Dutch","Turkish","Polish")
        val codes = arrayOf("en","hi","es","fr","de",
            "ar","zh-CN","ja","ko","pt","ru","it","nl","tr","pl")
        AlertDialog.Builder(this).setTitle("🌐 Translate Page")
            .setItems(languages) { _, which ->
                loadUrl("https://translate.google.com/translate?sl=auto" +
                    "&tl=${codes[which]}&u=${URLEncoder.encode(url, "UTF-8")}")
                Toast.makeText(this, "Translating to ${languages[which]}",
                    Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun addToReadingList() {
        val tab = tabManager.getCurrentTab() ?: return
        if (tab.url.startsWith("file://")) {
            Toast.makeText(this, "Cannot save this page", Toast.LENGTH_SHORT).show()
            return
        }
        lifecycleScope.launch {
            if (db.readingDao().isInReadingList(tab.url)) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity,
                        "Already in reading list", Toast.LENGTH_SHORT).show()
                }
                return@launch
            }
            db.readingDao().insert(ReadingItem(title = tab.title, url = tab.url))
            runOnUiThread {
                Toast.makeText(this@MainActivity,
                    "📖 Added to reading list", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun printPage() {
        val url = tabManager.getCurrentTab()?.url ?: ""
        if (url.startsWith("file://")) {
            Toast.makeText(this, "Nothing to print", Toast.LENGTH_SHORT).show()
            return
        }
        val wv = getCurrentWebView() ?: return
        val pm = getSystemService(PRINT_SERVICE) as PrintManager
        val jobName = wv.title ?: "Brahman Browser"
        pm.print(jobName, wv.createPrintDocumentAdapter(jobName), null)
    }

    private fun startVoiceSearch() {
        try {
            voiceLauncher.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to search...")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            })
        } catch (e: Exception) {
            Toast.makeText(this, "Voice search not available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startQrScanner() {
        try {
            qrScanLauncher.launch(ScanOptions().apply {
                setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                setPrompt("Scan a QR Code")
                setBeepEnabled(true)
                setOrientationLocked(false)
            })
        } catch (e: Exception) {
            Toast.makeText(this, "QR scanner error", Toast.LENGTH_SHORT).show()
        }
    }

    private fun reopenLastClosedTab() {
        if (closedTabHistory.isNotEmpty()) {
            val url = closedTabHistory.removeLast()
            openTab(url)
            Toast.makeText(this, "Reopened: ${extractDomain(url)}",
                Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "No recently closed tabs", Toast.LENGTH_SHORT).show()
        }
    }

    private fun copyFullUrl() {
        val url = getCurrentWebView()?.url ?: tabManager.getCurrentTab()?.url ?: ""
        if (url.isEmpty() || url.startsWith("file://")) {
            Toast.makeText(this, "Nothing to copy", Toast.LENGTH_SHORT).show()
            return
        }
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("url", url))
        Toast.makeText(this, "URL copied!", Toast.LENGTH_SHORT).show()
    }

    private fun viewPageSource() {
        val url = tabManager.getCurrentTab()?.url ?: ""
        if (url.startsWith("file://")) {
            Toast.makeText(this, "No source for this page", Toast.LENGTH_SHORT).show()
            return
        }
        loadUrl("view-source:$url")
    }

    private fun openInExternalApp(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            Toast.makeText(this, "No app found to open this URL",
                Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleReaderMode() {
        val url = tabManager.getCurrentTab()?.url ?: ""
        if (url.startsWith("file://")) {
            Toast.makeText(this, "Reader mode works on web pages",
                Toast.LENGTH_SHORT).show()
            return
        }
        if (!isReaderModeOn) {
            getCurrentWebView()?.evaluateJavascript(READER_JS, null)
            isReaderModeOn = true
            Toast.makeText(this, "Reader Mode ON", Toast.LENGTH_SHORT).show()
        } else {
            getCurrentWebView()?.reload()
            isReaderModeOn = false
            Toast.makeText(this, "Reader Mode OFF", Toast.LENGTH_SHORT).show()
        }
    }

    private fun fireButtonClearAll() {
        AlertDialog.Builder(this).setTitle("🔥 Clear All Data")
            .setMessage("Clear ALL history, bookmarks, downloads, passwords, " +
                "reading list, cookies and cache?")
            .setPositiveButton("Clear Everything") { _, _ ->
                lifecycleScope.launch {
                    db.historyDao().clearAll()
                    db.bookmarkDao().deleteAll()
                    db.downloadDao().deleteAll()
                    db.passwordDao().deleteAll()
                    db.readingDao().deleteAll()
                    runOnUiThread {
                        CookieManager.getInstance().removeAllCookies(null)
                        CookieManager.getInstance().flush()
                        WebStorage.getInstance().deleteAllData()
                        applicationContext.cacheDir.deleteRecursively()
                        SessionManager.clearSession(this@MainActivity)
                        Toast.makeText(this@MainActivity,
                            "🔥 All data cleared", Toast.LENGTH_SHORT).show()
                    }
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun showLinkOptions(url: String) {
        AlertDialog.Builder(this).setTitle(extractDomain(url))
            .setItems(arrayOf(
                "Open in New Tab", "Copy Link", "Share", "Download"
            )) { _, which ->
                when (which) {
                    0 -> openTab(url)
                    1 -> {
                        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                            .setPrimaryClip(ClipData.newPlainText("link", url))
                        Toast.makeText(this, "Link copied", Toast.LENGTH_SHORT).show()
                    }
                    2 -> startActivity(Intent.createChooser(
                        Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, url)
                        }, "Share link"))
                    3 -> {
                        val fileName = URLUtil.guessFileName(url, null, null)
                        (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(
                            DownloadManager.Request(Uri.parse(url))
                                .setTitle(fileName).setDescription("Downloading...")
                                .setNotificationVisibility(
                                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                .setDestinationInExternalPublicDir(
                                    Environment.DIRECTORY_DOWNLOADS, fileName))
                        Toast.makeText(this, "Downloading: $fileName",
                            Toast.LENGTH_SHORT).show()
                    }
                }
            }.show()
    }

    private fun showImageOptions(url: String) {
        AlertDialog.Builder(this).setTitle("Image")
            .setItems(arrayOf("Open Image", "Copy URL", "Download")) { _, which ->
                when (which) {
                    0 -> loadUrl(url)
                    1 -> {
                        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                            .setPrimaryClip(ClipData.newPlainText("image url", url))
                        Toast.makeText(this, "Image URL copied", Toast.LENGTH_SHORT).show()
                    }
                    2 -> {
                        val fileName = URLUtil.guessFileName(url, null, "image/*")
                        (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(
                            DownloadManager.Request(Uri.parse(url))
                                .setTitle(fileName).setDescription("Downloading image...")
                                .setNotificationVisibility(
                                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                .setDestinationInExternalPublicDir(
                                    Environment.DIRECTORY_DOWNLOADS, fileName))
                        Toast.makeText(this, "Downloading image", Toast.LENGTH_SHORT).show()
                    }
                }
            }.show()
    }

    // ── Tab Grid ──────────────────────────────────────────────

    private fun setupTabGrid() { tabGridRecycler.layoutManager = GridLayoutManager(this, 2) }
    private fun openTabGrid() {
        refreshTabGrid(); tabGridOverlay.visibility = View.VISIBLE; hideKeyboard()
    }
    private fun closeTabGrid() { tabGridOverlay.visibility = View.GONE }

    private fun refreshTabGrid() {
        val count = tabManager.tabs.size
        tabCountLabel.text = "$count tab${if (count != 1) "s" else ""} open"
        tabGridRecycler.adapter = TabGridAdapter(
            tabs = tabManager.tabs,
            activeIndex = tabManager.getCurrentTabIndex(),
            onTabClick = { index -> switchToExistingTab(index); closeTabGrid() },
            onTabClose = { index -> closeTab(index) }
        )
    }

    // ── Gesture Detector ─────────────────────────────────────

    private fun setupGestureDetector() {
        gestureDetector = GestureDetector(this,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onFling(
                    e1: MotionEvent?, e2: MotionEvent,
                    velocityX: Float, velocityY: Float
                ): Boolean {
                    val diffX = e2.x - (e1?.x ?: 0f)
                    val diffY = e2.y - (e1?.y ?: 0f)
                    if (Math.abs(diffX) > Math.abs(diffY) &&
                        Math.abs(diffX) > 150 && Math.abs(velocityX) > 1000) {
                        val idx = tabManager.getCurrentTabIndex()
                        if (diffX > 0 && idx > 0) switchToExistingTab(idx - 1)
                        else if (diffX < 0 && idx < tabManager.tabs.size - 1)
                            switchToExistingTab(idx + 1)
                        return true
                    }
                    return false
                }
            })
    }

    // ── Window Insets ─────────────────────────────────────────

    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(navigationBar) { view, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updateLayoutParams<ViewGroup.MarginLayoutParams> {
                bottomMargin = systemBars.bottom + 4
            }
            insets
        }
    }

    // ── Bind Views ────────────────────────────────────────────

    private fun bindViews() {
        swipeRefresh = findViewById(R.id.swipeRefresh)
        webViewContainer = findViewById(R.id.webViewContainer)
        lockIcon = findViewById(R.id.lockIcon)
        addressBar = findViewById(R.id.addressBar)
        progressBar = findViewById(R.id.progressBar)
        addressBarRow = findViewById(R.id.addressBarRow)
        navigationBar = findViewById(R.id.navigationBar)
        topBar = findViewById(R.id.topBar)
        tabsRow = findViewById(R.id.tabsRow)
        btnBookmark = findViewById(R.id.btnBookmark)
        btnIncognito = findViewById(R.id.btnIncognito)
        btnDesktop = findViewById(R.id.btnDesktop)
        btnShield = findViewById(R.id.btnShield)
        shieldBadge = findViewById(R.id.shieldBadge)
        btnMore = findViewById(R.id.btnMore)
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)
        btnRefresh = findViewById(R.id.btnRefresh)
        btnHome = findViewById(R.id.btnHome)
        btnNewTab = findViewById(R.id.btnNewTab)
        btnTabGrid = findViewById(R.id.btnTabGrid)
        btnFullscreen = findViewById(R.id.btnFullscreen)
        btnMic = findViewById(R.id.btnMic)
        tabRecycler = findViewById(R.id.tabRecycler)
        findInPageBar = findViewById(R.id.findInPageBar)
        findInput = findViewById(R.id.findInput)
        findMatchCount = findViewById(R.id.findMatchCount)
        btnFindPrev = findViewById(R.id.btnFindPrev)
        btnFindNext = findViewById(R.id.btnFindNext)
        btnFindClose = findViewById(R.id.btnFindClose)
        tabGridOverlay = findViewById(R.id.tabGridOverlay)
        tabGridRecycler = findViewById(R.id.tabGridRecycler)
        tabCountLabel = findViewById(R.id.tabCountLabel)
        btnGridClose = findViewById(R.id.btnGridClose)
        btnGridNewTab = findViewById(R.id.btnGridNewTab)
        btnCloseAllTabs = findViewById(R.id.btnCloseAllTabs)
        btnGridAddNewTab = findViewById(R.id.btnGridAddNewTab)
        fullscreenVideoContainer = findViewById(R.id.fullscreenVideoContainer)
        suggestionsPanel = findViewById(R.id.suggestionsPanel)
        suggestionsRecycler = findViewById(R.id.suggestionsRecycler)
    }

    // ── RecyclerView (Tab strip) ──────────────────────────────

    private fun setupRecyclerView() {
        browserAdapter = BrowserAdapter(
            tabs = tabManager.tabs,
            onTabClick = { index -> switchToExistingTab(index) },
            onTabClose = { index -> closeTab(index) }
        )
        tabRecycler.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        tabRecycler.adapter = browserAdapter
    }

    // ── Listeners ─────────────────────────────────────────────

    private fun setupListeners() {
        addressBar.setOnFocusChangeListener { _, hasFocus ->
            isAddressBarFocused = hasFocus
            val currentUrl = tabManager.getCurrentTab()?.url ?: ""
            if (hasFocus) {
                if (!currentUrl.startsWith("file://")) {
                    addressBar.setText(currentUrl)
                    addressBar.selectAll()
                }
                val query = addressBar.text.toString()
                if (query.isNotEmpty()) {
                    suggestionRunnable?.let { suggestionHandler.removeCallbacks(it) }
                    suggestionRunnable = Runnable { updateSuggestions(query) }
                    suggestionHandler.postDelayed(suggestionRunnable!!, 200)
                }
            } else {
                hideSuggestions()
                if (currentUrl.startsWith("file://")) addressBar.setText("")
                else setAddressBarSilently(extractDomain(currentUrl))
            }
        }

        addressBar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (!isAddressBarFocused) return
                val query = s?.toString() ?: ""
                suggestionRunnable?.let { suggestionHandler.removeCallbacks(it) }
                suggestionRunnable = Runnable { updateSuggestions(query) }
                suggestionHandler.postDelayed(suggestionRunnable!!, 200)
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        addressBar.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                event?.keyCode == KeyEvent.KEYCODE_ENTER) {
                val input = addressBar.text.toString().trim()
                if (input.isNotEmpty()) {
                    hideSuggestions()
                    loadUrl(resolveUrl(input))
                }
                hideKeyboard()
                true
            } else false
        }

        lockIcon.setOnClickListener { showCertificateInfo() }
        btnMic.setOnClickListener { startVoiceSearch() }

        btnBookmark.setOnClickListener {
            val url = tabManager.getCurrentTab()?.url ?: ""
            if (url.startsWith("file://")) return@setOnClickListener
            lifecycleScope.launch {
                val isBookmarked = db.bookmarkDao().isBookmarked(url)
                if (isBookmarked) {
                    db.bookmarkDao().deleteByUrl(url)
                    btnBookmark.setImageResource(R.drawable.ic_bookmark)
                    Toast.makeText(this@MainActivity,
                        "Bookmark removed", Toast.LENGTH_SHORT).show()
                } else {
                    val title = tabManager.getCurrentTab()?.title ?: url
                    db.bookmarkDao().insert(BookmarkItem(title = title, url = url))
                    btnBookmark.setImageResource(R.drawable.ic_bookmark_filled)
                    Toast.makeText(this@MainActivity,
                        "Bookmarked!", Toast.LENGTH_SHORT).show()
                }
            }
        }

        btnShield.setOnClickListener {
            val url = tabManager.getCurrentTab()?.url ?: ""
            if (url.startsWith("file://")) {
                Toast.makeText(this, "Shields protect web pages",
                    Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            ShieldsPanel(this, url, adBlocker) {
                updateShieldIcon(url); getCurrentWebView()?.reload()
            }.show()
        }

        btnTabGrid.setOnClickListener { openTabGrid() }
        btnGridClose.setOnClickListener { closeTabGrid() }
        btnGridNewTab.setOnClickListener { openTab(NEW_TAB_URL); closeTabGrid() }
        btnGridAddNewTab.setOnClickListener { openTab(NEW_TAB_URL); closeTabGrid() }

        btnCloseAllTabs.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Close All Tabs")
                .setMessage("Close all ${tabManager.tabs.size} tabs?")
                .setPositiveButton("Close All") { _, _ ->
                    val tabsCopy = tabManager.tabs.toList()
                    tabsCopy.forEach { tab ->
                        if (!tab.url.startsWith("file://"))
                            closedTabHistory.add(tab.url)
                        tab.webView?.let { wv ->
                            webViewContainer.removeView(wv); wv.destroy()
                        }
                        tab.webView = null
                    }
                    tabManager.tabs.clear()
                    browserAdapter.notifyDataSetChanged()
                    openTab(NEW_TAB_URL)
                    closeTabGrid()
                }.setNegativeButton("Cancel", null).show()
        }

        btnBack.setOnClickListener {
            if (getCurrentWebView()?.canGoBack() == true) getCurrentWebView()?.goBack()
        }
        btnForward.setOnClickListener {
            if (getCurrentWebView()?.canGoForward() == true) getCurrentWebView()?.goForward()
        }
        btnRefresh.setOnClickListener { getCurrentWebView()?.reload() }
        btnHome.setOnClickListener { loadUrl(prefs.homepage) }
        btnNewTab.setOnClickListener { openTab(NEW_TAB_URL) }
        btnFullscreen.setOnClickListener { toggleFullscreen() }

        btnIncognito.setOnClickListener {
            tabManager.toggleIncognito()
            val isIncognito = tabManager.getCurrentTab()?.isIncognito == true
            btnIncognito.alpha = if (isIncognito) 1.0f else 0.5f
            CookieManager.getInstance().setAcceptCookie(!isIncognito)
            Toast.makeText(this,
                if (isIncognito) "Incognito ON" else "Incognito OFF",
                Toast.LENGTH_SHORT).show()
        }

        btnDesktop.setOnClickListener {
            tabManager.toggleDesktopMode()
            val isDesktop = tabManager.getCurrentTab()?.isDesktop == true
            btnDesktop.alpha = if (isDesktop) 1.0f else 0.5f
            getCurrentWebView()?.settings?.userAgentString = if (isDesktop)
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
                    "AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36"
            else ""
            getCurrentWebView()?.reload()
        }

        findInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val q = s.toString().trim()
                val wv = getCurrentWebView()
                if (q.isNotEmpty()) wv?.findAllAsync(q)
                else { wv?.clearMatches(); findMatchCount.text = "" }
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        findInput.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                getCurrentWebView()?.findNext(true); true
            } else false
        }
        btnFindPrev.setOnClickListener { getCurrentWebView()?.findNext(false) }
        btnFindNext.setOnClickListener { getCurrentWebView()?.findNext(true) }
        btnFindClose.setOnClickListener { closeFindInPage() }

        btnMore.setOnClickListener { view ->
            val popup = PopupMenu(this, view)
            popup.menu.add(0, 1, 0, "Bookmarks")
            popup.menu.add(0, 2, 0, "History")
            popup.menu.add(0, 3, 0, "Downloads")
            popup.menu.add(0, 4, 0, "🔑 Passwords")
            popup.menu.add(0, 5, 0, "📖 Reading List")
            popup.menu.add(0, 6, 0, "Settings")
            popup.menu.add(0, 7, 0, "Share")
            popup.menu.add(0, 8, 0, "Find in page")
            popup.menu.add(0, 9, 0,
                if (isReaderModeOn) "Exit Reader Mode" else "Reader Mode")
            popup.menu.add(0, 10, 0, "🌐 Translate Page")
            popup.menu.add(0, 11, 0, "➕ Save to Reading List")
            popup.menu.add(0, 12, 0, "Print / Save PDF")
            popup.menu.add(0, 13, 0, "🔍 Scan QR Code")
            popup.menu.add(0, 14, 0, "↩ Reopen Closed Tab")
            popup.menu.add(0, 15, 0, "Zoom In")
            popup.menu.add(0, 16, 0, "Zoom Out")
            popup.menu.add(0, 17, 0, "📋 Copy URL")
            popup.menu.add(0, 18, 0, "🔗 Open in External App")
            popup.menu.add(0, 19, 0, "📄 View Page Source")
            popup.menu.add(0, 20, 0, "📺 Picture in Picture")
            popup.menu.add(0, 21, 0, "🔥 Clear All Data")
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    1 -> { bookmarkLauncher.launch(
                        Intent(this, BookmarkActivity::class.java)); true }
                    2 -> { historyLauncher.launch(
                        Intent(this, HistoryActivity::class.java)); true }
                    3 -> { downloadLauncher.launch(
                        Intent(this, DownloadActivity::class.java)); true }
                    4 -> { passwordLauncher.launch(
                        Intent(this, PasswordActivity::class.java)); true }
                    5 -> { readingLauncher.launch(
                        Intent(this, ReadingActivity::class.java)); true }
                    6 -> { settingsLauncher.launch(
                        Intent(this, SettingsActivity::class.java)); true }
                    7 -> {
                        val url = getCurrentWebView()?.url ?: ""
                        if (url.isEmpty() || url.startsWith("file://"))
                            Toast.makeText(this, "Nothing to share",
                                Toast.LENGTH_SHORT).show()
                        else startActivity(Intent.createChooser(
                            Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"; putExtra(Intent.EXTRA_TEXT, url)
                            }, "Share URL"))
                        true
                    }
                    8 -> { openFindInPage(); true }
                    9 -> { toggleReaderMode(); true }
                    10 -> { translatePage(); true }
                    11 -> { addToReadingList(); true }
                    12 -> { printPage(); true }
                    13 -> { startQrScanner(); true }
                    14 -> { reopenLastClosedTab(); true }
                    15 -> { getCurrentWebView()?.zoomIn(); true }
                    16 -> { getCurrentWebView()?.zoomOut(); true }
                    17 -> { copyFullUrl(); true }
                    18 -> {
                        val url = getCurrentWebView()?.url ?: ""
                        if (url.isNotEmpty() && !url.startsWith("file://"))
                            openInExternalApp(url); true
                    }
                    19 -> { viewPageSource(); true }
                    20 -> { enterPipMode(); true }
                    21 -> { fireButtonClearAll(); true }
                    else -> false
                }
            }
            popup.show()
        }
    }

    // ── Session ───────────────────────────────────────────────

    private fun showRestoreSessionDialog(
        savedTabs: List<BrowserTab>, savedIndex: Int
    ) {
        AlertDialog.Builder(this)
            .setTitle("🔄 Restore Session?")
            .setMessage("Restore ${savedTabs.size} tab${if (savedTabs.size != 1) "s" else ""} from last session?")
            .setPositiveButton("Restore") { _, _ ->
                savedTabs.forEachIndexed { index, tab ->
                    val wv = createWebView()
                    tab.webView = wv
                    tabManager.addTab(tab)
                    if (index == savedIndex) wv.visibility = View.VISIBLE
                    wv.loadUrl(tab.url)
                }
                browserAdapter.notifyDataSetChanged()
                val targetIndex = savedIndex.coerceIn(0, tabManager.tabs.size - 1)
                tabManager.switchToTab(targetIndex)
                val url = tabManager.getCurrentTab()?.url ?: NEW_TAB_URL
                updateUIForUrl(url)
                updateNavButtons()
                updateShieldIcon(url)
                updateSwipeRefreshTarget()
                SessionManager.clearSession(this)
            }
            .setNegativeButton("New Session") { _, _ ->
                SessionManager.clearSession(this)
                openTab(NEW_TAB_URL)
            }
            .setCancelable(false).show()
    }

    private fun handleShortcutIntent(intent: Intent?): Boolean {
        return when (intent?.action) {
            "com.brahmanlabs.browser.NEW_TAB" -> { openTab(NEW_TAB_URL); true }
            "com.brahmanlabs.browser.INCOGNITO" -> {
                openTab(NEW_TAB_URL, incognito = true)
                tabManager.getCurrentTab()?.isIncognito = true
                btnIncognito.alpha = 1.0f
                CookieManager.getInstance().setAcceptCookie(false)
                Toast.makeText(this, "Incognito tab opened", Toast.LENGTH_SHORT).show()
                true
            }
            "com.brahmanlabs.browser.QR_SCAN" -> { startQrScanner(); false }
            else -> false
        }
    }

    private fun resolveIncomingIntent(intent: Intent?): String? {
        if (intent == null) return null
        return when (intent.action) {
            Intent.ACTION_VIEW -> intent.dataString
            Intent.ACTION_SEND -> if (intent.type == "text/plain")
                intent.getStringExtra(Intent.EXTRA_TEXT)?.let { resolveUrl(it) } else null
            else -> null
        }
    }

    // ── Helpers ───────────────────────────────────────────────

    private fun extractDomain(url: String): String = try {
        Uri.parse(url).host?.removePrefix("www.") ?: url
    } catch (e: Exception) { url }

    private fun resolveUrl(input: String): String = when {
        input.startsWith("http://") || input.startsWith("https://") -> input
        input.startsWith("view-source:") -> input
        input.contains(".") && !input.contains(" ") -> "https://$input"
        else -> prefs.getSearchUrl(input)
    }

    private fun updateNavButtons() {
        val wv = getCurrentWebView()
        btnBack.alpha = if (wv?.canGoBack() == true) 1.0f else 0.4f
        btnForward.alpha = if (wv?.canGoForward() == true) 1.0f else 0.4f
    }

    private fun updateShieldBadge() {
        val count = adBlocker.getBlockedCount()
        shieldBadge.visibility = if (count > 0) View.VISIBLE else View.GONE
        if (count > 0) shieldBadge.text = if (count > 99) "99" else count.toString()
    }

    private fun updateShieldIcon(url: String) {
        btnShield.alpha = if (adBlocker.isShieldsEnabled(url)) 1.0f else 0.4f
    }

    private fun updateBookmarkIcon(url: String) {
        lifecycleScope.launch {
            val isBookmarked = db.bookmarkDao().isBookmarked(url)
            btnBookmark.setImageResource(
                if (isBookmarked) R.drawable.ic_bookmark_filled
                else R.drawable.ic_bookmark)
            btnBookmark.alpha = 1.0f
        }
    }

    private fun openFindInPage() {
        findInPageBar.visibility = View.VISIBLE
        findInput.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(findInput, InputMethodManager.SHOW_IMPLICIT)
        findInput.text.clear()
        findMatchCount.text = ""
    }

    private fun closeFindInPage() {
        findInPageBar.visibility = View.GONE
        getCurrentWebView()?.clearMatches()
        findInput.text.clear()
        findMatchCount.text = ""
        hideKeyboard()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(addressBar.windowToken, 0)
        addressBar.clearFocus()
        isAddressBarFocused = false
        hideSuggestions()
    }

    private fun requestPermissionsIfNeeded(permissions: Array<String>) {
        val needed = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }.toTypedArray()
        if (needed.isNotEmpty())
            ActivityCompat.requestPermissions(this, needed, PERMISSION_REQUEST_CODE)
    }

    // ── Lifecycle Events ──────────────────────────────────────

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (handleShortcutIntent(intent)) return
        val url = resolveIncomingIntent(intent)
        if (!url.isNullOrEmpty()) openTab(url)
    }

    override fun onPause() {
        super.onPause()
        if (tabManager.tabs.isNotEmpty()) {
            SessionManager.saveSession(
                this, tabManager.tabs, tabManager.getCurrentTabIndex())
        }
    }

    override fun onStop() {
        super.onStop()
        if (adBlocker.hasAnyForgetOnClose()) {
            tabManager.tabs.forEach { tab ->
                if (adBlocker.isForgetOnClose(tab.url)) {
                    CookieManager.getInstance().removeAllCookies(null)
                    CookieManager.getInstance().flush()
                    WebStorage.getInstance().deleteAllData()
                }
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (customView != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            enterPipMode()
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: android.content.res.Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            topBar.visibility = View.GONE
            tabsRow.visibility = View.GONE
            navigationBar.visibility = View.GONE
        } else {
            if (!isFullscreen) {
                topBar.visibility = View.VISIBLE
                tabsRow.visibility = View.VISIBLE
                navigationBar.visibility = View.VISIBLE
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) { super.onRequestPermissionsResult(requestCode, permissions, grantResults) }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            when {
                suggestionsPanel.visibility == View.VISIBLE -> {
                    hideSuggestions(); hideKeyboard()
                }
                customView != null -> hideVideoFullscreen()
                isFullscreen -> toggleFullscreen()
                tabGridOverlay.visibility == View.VISIBLE -> closeTabGrid()
                findInPageBar.visibility == View.VISIBLE -> closeFindInPage()
                getCurrentWebView()?.canGoBack() == true -> getCurrentWebView()?.goBack()
                else -> return super.onKeyDown(keyCode, event)
            }
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        historyDebounceRunnable?.let { historyDebounceHandler.removeCallbacks(it) }
        suggestionRunnable?.let { suggestionHandler.removeCallbacks(it) }
        tabManager.tabs.forEach { tab ->
            tab.webView?.destroy()
            tab.webView = null
        }
        super.onDestroy()
    }
}
